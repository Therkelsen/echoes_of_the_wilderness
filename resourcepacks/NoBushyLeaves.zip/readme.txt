How to use.

Have both Stay True and this Pack selected 
be sure to give this back priority 
(be at the top of the list in selected, above Stay True) 

				Example.

Avaliable						Selected

Resouse Pack					ST_NoBushyLeaves
Resorse Pack					Stay_True