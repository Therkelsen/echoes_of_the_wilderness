----------------[Terms of use]---------------------

You may use everything we made in this pack using NegativeSpaces4 under Creative Commons Attribution 4.0 International terms.
If you use anything out of this pack that includes the NegativeSpaces4 resource pack, you need to credit AmberW/AmberWat.

Using anything aside from the NegativeSpaces4 pack you also have to follow Creative Commons Attribution 4.0 International terms

----------------[Credit]---------------------------


--Pack Creators:--

mr_ch0c0late (Creator and Idea)

Curse Forge: 		https://www.curseforge.com/members/mr_ch0c0late1
Planet Minecraft: 	https://www.planetminecraft.com/member/mr_ch0c0late1/
Twitter: 			https://twitter.com/mr_ch0c0late1



Zartrix 

Curse Forge:		https://www.curseforge.com/members/zartrix
Reddit: 			https://www.reddit.com/user/Zartrix



AmberW/AmberWat

GitHub:			https://github.com/AmberWat
Discord(Minecraft Commands)